<script>
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.8/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.6.8/firebase-analytics.js";
  const firebaseConfig = {
    apiKey: "AIzaSyCdpBIdigGq1ew-zcfxdepxpbZNP3MOzC4",
    authDomain: "webportal-b0d16.firebaseapp.com",
    projectId: "webportal-b0d16",
    storageBucket: "webportal-b0d16.appspot.com",
    messagingSenderId: "984212010418",
    appId: "1:984212010418:web:76a5021e0e3c029647e0ab",
    measurementId: "G-7QLBQL6EJ7"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>